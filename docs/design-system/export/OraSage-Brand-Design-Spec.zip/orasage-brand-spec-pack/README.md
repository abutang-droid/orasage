# OraSage / 海棠未眠

中文 locale 用中文；其它语言仅 OraSage。见 OraSage-Brand-Spec.md §1.0。
