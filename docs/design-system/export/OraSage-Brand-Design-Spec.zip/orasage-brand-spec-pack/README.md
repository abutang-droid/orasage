# 海棠未眠 OraSage

中文：海棠未眠为主、OraSage 为辅。其它语言仅 OraSage。见 OraSage-Brand-Spec.md §1.0。
