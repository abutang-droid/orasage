# OraSage 品牌设计规范 · 导出包

导出自仓库 canonical 文档（VI v1.0 已确认 2026-07-08 + Design System v1.1 Revised）。

## 阅读顺序

1. `OraSage-Brand-Design-Spec.pdf` — 8 页精编规范（推荐）
2. `OraSage-Brand-Design-Spec.html` — 同内容网页版（需联网加载字体）
3. `docs/OraSage-VI-v1.0.md` — 品牌识别层全文
4. `docs/OraSage-Design-System-v1.1-Revised.md` — 界面层全文

## 资产

| 路径 | 内容 |
| :--- | :--- |
| `logo/` | 玄璧图形标 ink / paper / cinnabar |
| `subbrands/` | BaZi / ZiWei / Manto / Energy |
| `favicon/icon.svg` | 墨底反白玄璧 |
| `orasage-tokens.css` | 全站 CSS token |
| `bazi-report-vibe.css` | 八字报告赭石皮肤（产品层，不替代 VI） |

字标与图形标默认分开使用：顶栏只用字标 `OraSage`，符号位只用玄璧。
